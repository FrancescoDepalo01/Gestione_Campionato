﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Text;
using System.Threading.Tasks;

namespace GestioneCampionato
{
    public class Grafica
    {
        // COMANDI SCRITTA GESTIONE CAMPIONATO;
        // COMANDI PER DETERMINARE LA POSIZIONE DELLA SCRITTA
        public static void DisegnaTitolo()
        {
            
            int A = 2;
            int B = 5;

            Console.ForegroundColor = ConsoleColor.Blue;
            Console.SetCursorPosition(A, B);
            Console.WriteLine(" ██████╗ ███████╗███████╗████████╗██╗ ██████╗ ███╗   ██╗███████╗     ██████╗ █████╗ ███╗   ███╗██████╗ ██╗ ██████╗ ███╗   ██╗ █████╗ ████████╗ ██████╗ ");
            B++;
            Console.SetCursorPosition(A, B);
            Console.WriteLine("██╔════╝ ██╔════╝██╔════╝╚══██╔══╝██║██╔═══██╗████╗  ██║██╔════╝    ██╔════╝██╔══██╗████╗ ████║██╔══██╗██║██╔═══██╗████╗  ██║██╔══██╗╚══██╔══╝██╔═══██╗");
            B++;
            Console.SetCursorPosition(A, B);
            Console.WriteLine("██║  ███╗█████╗  ███████╗   ██║   ██║██║   ██║██╔██╗ ██║█████╗      ██║     ███████║██╔████╔██║██████╔╝██║██║   ██║██╔██╗ ██║███████║   ██║   ██║   ██║");
            B++;
            Console.SetCursorPosition(A, B);
            Console.WriteLine("██║   ██║██╔══╝  ╚════██║   ██║   ██║██║   ██║██║╚██╗██║██╔══╝      ██║     ██╔══██║██║╚██╔╝██║██╔═══╝ ██║██║   ██║██║╚██╗██║██╔══██║   ██║   ██║   ██║");
            B++;
            Console.SetCursorPosition(A, B);
            Console.WriteLine("╚██████╔╝███████╗███████║   ██║   ██║╚██████╔╝██║ ╚████║███████╗    ╚██████╗██║  ██║██║ ╚═╝ ██║██║     ██║╚██████╔╝██║ ╚████║██║  ██║   ██║   ╚██████╔╝");
            B++;
            Console.SetCursorPosition(A, B);
            Console.WriteLine(" ╚═════╝ ╚══════╝╚══════╝   ╚═╝   ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚══════╝     ╚═════╝╚═╝  ╚═╝╚═╝     ╚═╝╚═╝     ╚═╝ ╚═════╝ ╚═╝  ╚═══╝╚═╝  ╚═╝   ╚═╝    ╚═════╝ ");
            
            Console.ReadKey();
        }

        public static void Menu()
        {
            Console.CursorVisible = false;
            String[] Menu = { "Squadre", "Classifica", "Esci" };
            int OpzioneSelezionata = 0;
            Console.ResetColor();
            while (true)
            {
                for (int i = 0; i < Menu.Length; i++)
                {
                    if (i == OpzioneSelezionata)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    Console.SetCursorPosition(74, 15 + i * 2);
                    Console.WriteLine(Menu[i]);
                }
            } // => BARRA DEL MENU

            ConsoleKeyInfo input = Console.ReadKey();
            switch (input.Key)
            {
                case ConsoleKey.UpArrow:
                    OpzioneSelezionata--;
                    if (OpzioneSelezionata < 0)
                    {
                        OpzioneSelezionata = Menu.Length - 1;
                    }
                    break;
                case ConsoleKey.DownArrow:
                    OpzioneSelezionata++;
                    if (OpzioneSelezionata>=Menu.Length)
                    {
                        OpzioneSelezionata = 0;
                    }
                    break;
                case ConsoleKey.Enter:
                    switch (OpzioneSelezionata)
                    {
                        case 0:
                            Console.SetCursorPosition(38,25);
                            Console.Clear();
                            Console.WriteLine(@"   





                     
                      ,;;;:.
                     ;;''''`:
                     ;(  O O|              ,;;,
                      |   _\|              \  |
                       \__-/              ,' /
                       |   |             /  /
                 _,--''`---'''-------.,-'  /
               ,'  /          `.     |  _,'
             ,'    |====== WM =|     |-'
            \      ,======|  |=|''---'
           / `.  ,' \      \/ /
         ,'. ,'`'   | --._    |
       ,'  ,'       |         |
   __,' _,'         \    -._  |
  `- ,-'            |---------)
 ';;'               ;:::::::::|
                   ;:::::::::::\
                  /::::::;:::::|
                 /_:::::/\:::::_\
                 / `-:_/  \,-' |
                /    /     \   |
                |   |      | _,)
                \_,-\      |   |
                 \   |     |   |
                  |__|      \,-|
                  /##|      |  |
                 \##/       |  |
                ,-'''-.     |,-|
               // \_/ \\    `.##\
               |\_/ \_/|      `--`
               \/ \_/ \/
                `-...-'





------------------------------------------------

");             // => DISEGNO DI UN CALCIATORE

                            int A = 0;
                            int B = 0;
                            Console.ForegroundColor=ConsoleColor.DarkCyan;
                            Console.SetCursorPosition(A,B);
                            Console.WriteLine("███████╗ ██████╗ ██╗   ██╗ █████╗ ██████╗ ██████╗ ███████╗");
                            B++;
                            Console.SetCursorPosition(A, B);
                            Console.WriteLine("██╔════╝██╔═══██╗██║   ██║██╔══██╗██╔══██╗██╔══██╗██╔════╝");
                            B++;
                            Console.SetCursorPosition(A, B);
                            Console.WriteLine("███████╗██║   ██║██║   ██║███████║██║  ██║██████╔╝█████╗  ");
                            B++;
                            Console.SetCursorPosition(A, B);
                            Console.WriteLine("╚════██║██║▄▄ ██║██║   ██║██╔══██║██║  ██║██╔══██╗██╔══╝  ");
                            B++;
                            Console.SetCursorPosition(A, B);
                            Console.WriteLine("███████║╚██████╔╝╚██████╔╝██║  ██║██████╔╝██║  ██║███████╗");
                            B++;
                            Console.SetCursorPosition(A, B);
                            Console.WriteLine("╚══════╝ ╚══▀▀═╝  ╚═════╝ ╚═╝  ╚═╝╚═════╝ ╚═╝  ╚═╝╚══════╝");

                            Informazioni();
                            break;

                        case 1:
                            Console.SetCursorPosition(38, 25);
                            Console.WriteLine("Hai selezionato 'Classifica'");
                            break;
                        case 2:
                            Console.SetCursorPosition(38, 25);
                            Console.WriteLine("Hai selezionato 'Esci'");
                            Environment.Exit(0);
                            Console.ReadKey();
                            break;
                    }
            }
        }   
        public static void Informazioni()
        {
            String[] Squadre = { "Atalanta", "Bologna", "Cremonese", "Empoli", "Fiorentina", "Juventus", "Inter", "Lazio", "Lecce", "Milan", "Monza", "Napoli", "Roma", "Salernitana", "Sampdoria", "Sassuolo", "Spezia", "Torino", "Udinese", "Verona" };
            int _riga = 0;      // Indice della riga selezionata
            Console.CursorVisible = false; // Nasconde il cursore;
            while (true)
            {
                for (int i = 0; i < Squadre.Length; i++)
                {
                    Console.SetCursorPosition((Console.WindowWidth / 2) - 20, (i * 2) + 5);
                    if (i == _riga)
                    {
                        Console.ForegroundColor = ConsoleColor.DarkCyan;
                    }
                    else
                    {
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    Console.Write(Squadre[i].PadRight(20)); // Stampa le squadre con una larghezza di 20 caratteri;

                    // Lettura Input da tastiera
                    ConsoleKeyInfo Input  = Console.ReadKey(true);
                    if (Input.Key == ConsoleKey.UpArrow)
                    {
                        _riga--;
                        if (_riga<0)
                        {
                            _riga = Squadre.Length - 1;
                        }
                    }
                    if (Input.Key == ConsoleKey.DownArrow)
                    {
                        _riga++;
                        if (_riga == Squadre.Length)
                        {
                            _riga = 0;
                        }

                    }
                    if (Input.Key == ConsoleKey.Enter)
                    {
                        Console.WriteLine($"Hai selezionato la sezione SQUADRE{ Squadre[_riga]}!");
                        break;
                    }
                    
                }
            }
        }
    }
}
